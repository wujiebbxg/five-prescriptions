---
name: markdown-converter
description: "Convert between Markdown and other formats (HTML, PDF, DOCX, etc.). Use when user needs to convert Markdown files or content to different formats, or convert other formats to Markdown."
---

# Markdown Converter

Convert Markdown to various formats and vice versa.

## Supported Conversions

### From Markdown
- **Markdown → HTML** - For web publishing
- **Markdown → PDF** - For documents/reports
- **Markdown → DOCX** - For Microsoft Word
- **Markdown → JSON** - For structured data

### To Markdown
- **HTML → Markdown** - Clean web content
- **DOCX → Markdown** - Convert Word documents
- **Text → Markdown** - Format plain text

## Tools Available

### 1. Markdown to HTML
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from md --to html --input "<markdown_content>" --output "/path/to/output.html"
```

### 2. Markdown to PDF
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from md --to pdf --input "<markdown_content>" --output "/path/to/output.pdf"
```

### 3. HTML to Markdown
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from html --to md --input "<html_content>" --output "/path/to/output.md"
```

### 4. Markdown to DOCX
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from md --to docx --input "<markdown_content>" --output "/path/to/output.docx"
```

## Parameters

| Parameter | Description |
|-----------|-------------|
| `--from` | Source format: `md`, `html`, `docx`, `txt` |
| `--to` | Target format: `md`, `html`, `pdf`, `docx`, `json` |
| `--input` | Input content (string) or use `--input-file` |
| `--input-file` | Path to input file |
| `--output` | Path to output file |
| `--title` | Document title (for PDF/DOCX) |

## Examples

### Convert Markdown to HTML
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from md --to html --input "# Hello\n\nThis is **bold** text." --output "/tmp/output.html"
```

### Convert HTML to Markdown
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from html --to md --input "<h1>Title</h1><p>Paragraph</p>" --output "/tmp/output.md"
```

### Convert file
```bash
python3 "/root/.openclaw/skills/markdown-converter/convert.py" --from md --to pdf --input-file "/path/to/input.md" --output "/path/to/output.pdf" --title "My Document"
```

## Dependencies

Required Python packages:
- `markdown` - For MD ↔ HTML
- `beautifulsoup4` - For HTML parsing
- `pypandoc` - For DOCX/PDF conversion (requires pandoc)

Install:
```bash
pip install markdown beautifulsoup4 pypandoc
```

For PDF conversion, also install:
```bash
apt-get install pandoc texlive-xetex  # Debian/Ubuntu
```

## Notes

- PDF conversion requires pandoc and LaTeX installed
- DOCX conversion requires pandoc
- Large files may take longer to convert
