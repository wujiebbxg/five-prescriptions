import json
import sys
import argparse
import urllib.request
import urllib.error
import ssl
import io

# Set UTF-8 encoding for Windows compatibility
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Constants
BAICHUAN_API_KEY = "sk-7466d0333b621ad2213488dd11afed4a"
GETNOTE_API_KEY = "MybZUTEYbSH1sIiUawjixxJHKg9bMVGxcTqeovYMRdq9Y2ry6Yj+LFeRTGJPaQ5V9vrqyQGQTlIORj5issPgMY/fWbCrQN3F4w=="
GETNOTE_IDS = {
    "nutrition": "w0E6PpEJ",
    "lifestyle": "w0E73xyn",
    "functional_medicine": "zJKPQaWn"
}

def call_baichuan(query):
    url = "https://api.baichuan-ai.com/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {BAICHUAN_API_KEY}"
    }
    data = {
        "model": "Baichuan-M3",
        "messages": [
            {"role": "user", "content": query}
        ],
        "temperature": 0.3,
        "max_tokens": 2048
    }
    
    try:
        print(f"[DEBUG] Calling Baichuan API...", file=sys.stderr)
        
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        # Create SSL context that allows us to connect even with self-signed certs
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, timeout=30, context=ssl_context) as response:
            print(f"[DEBUG] Status: {response.status}", file=sys.stderr)
            result = json.loads(response.read().decode('utf-8'))
            
            if "choices" in result and len(result["choices"]) > 0:
                message = result["choices"][0]["message"]
                # 优先使用 content，如果为空则使用 reasoning_content
                content = message.get("content", "")
                reasoning = message.get("reasoning_content", "")
                
                if content and content.strip():
                    print(content)
                elif reasoning and reasoning.strip():
                    print(reasoning)
                else:
                    print("Error: Empty response from Baichuan API.")
            else:
                print("Error: Unexpected Baichuan response format.")
                print(json.dumps(result, ensure_ascii=False, indent=2))
                
    except urllib.error.HTTPError as e:
        print(f"Error: Baichuan API HTTP Error {e.code}")
        print(e.read().decode('utf-8'))
    except urllib.error.URLError as e:
        print(f"Error: Baichuan API URL Error: {e.reason}")
    except TimeoutError:
        print("Error: Baichuan API request timeout (30s)")
    except Exception as e:
        print(f"Error: {e}")

def call_getnote(query, topic_id):
    url = "https://open-api.biji.com/getnote/openapi/knowledge/search"
    headers = {
        "Content-Type": "application/json",
        "Connection": "keep-alive",
        "Authorization": f"Bearer {GETNOTE_API_KEY}",
        "X-OAuth-Version": "1"
    }
    data = {
        "question": query,
        "topic_ids": [topic_id],
        "history": [],
        "deep_seek": False,
        "refs": False
    }
    
    try:
        print(f"[DEBUG] Calling GetNote API...", file=sys.stderr)
        
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, timeout=60, context=ssl_context) as response:
            print(f"[DEBUG] Status: {response.status}", file=sys.stderr)
            content_type = response.headers.get('Content-Type', '')
            
            if 'application/json' in content_type:
                result = json.loads(response.read().decode('utf-8'))
                # Try to find the answer field
                if "c" in result and "answers" in result["c"]:
                    print(result["c"]["answers"])
                elif "answer" in result:
                    print(result["answer"])
                elif "content" in result:
                    print(result["content"])
                elif "data" in result and isinstance(result["data"], dict):
                    if "answer" in result["data"]:
                        print(result["data"]["answer"])
                    elif "content" in result["data"]:
                        print(result["data"]["content"])
                    else:
                        print(json.dumps(result, ensure_ascii=False, indent=2))
                else:
                    print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(response.read().decode('utf-8'))
                
    except urllib.error.HTTPError as e:
        print(f"Error: GetNote API HTTP Error {e.code}")
        print(e.read().decode('utf-8'))
    except urllib.error.URLError as e:
        print(f"Error: GetNote API URL Error: {e.reason}")
    except TimeoutError:
        print("Error: GetNote API request timeout (60s)")
    except Exception as e:
        print(f"Error: {e}")

def main():
    parser = argparse.ArgumentParser(description="Medical Skill Helper")
    parser.add_argument("--type", required=True, choices=["medical", "nutrition", "lifestyle", "functional_medicine"],
                        help="Type of query")
    parser.add_argument("--query", required=True, help="User query")
    args = parser.parse_args()

    if args.type == "medical":
        call_baichuan(args.query)
    elif args.type in ["nutrition", "lifestyle", "functional_medicine"]:
        topic_id = GETNOTE_IDS[args.type]
        call_getnote(args.query, topic_id)
    else:
        print("Unknown type")

if __name__ == "__main__":
    main()
