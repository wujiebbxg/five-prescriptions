#!/usr/bin/env python3
"""
PDF 内容提取工具 - 用于运动心肺报告
支持文本型PDF和OCR识别扫描型PDF
"""

import sys
import os
import re

def extract_pdf_text(pdf_path):
    """
    提取PDF文本内容
    先尝试pdfplumber，如果内容太少则使用OCR
    """
    try:
        import pdfplumber
        
        text_content = []
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    text_content.append(text)
        
        full_text = '\n'.join(text_content)
        
        # 如果提取的文本太少，可能是扫描件，尝试OCR
        if len(full_text.strip()) < 200:
            print("文本内容较少，尝试OCR识别...", file=sys.stderr)
            return ocr_pdf(pdf_path)
        
        return full_text
        
    except Exception as e:
        print(f"pdfplumber提取失败: {e}", file=sys.stderr)
        return ocr_pdf(pdf_path)


def ocr_pdf(pdf_path):
    """
    使用OCR识别PDF内容
    """
    try:
        from pdf2image import convert_from_path
        import pytesseract
        
        print("正在转换PDF为图片...", file=sys.stderr)
        images = convert_from_path(pdf_path, dpi=300)
        
        text_content = []
        for i, image in enumerate(images):
            print(f"正在识别第 {i+1}/{len(images)} 页...", file=sys.stderr)
            text = pytesseract.image_to_string(image, lang='chi_sim+eng')
            text_content.append(text)
        
        return '\n'.join(text_content)
        
    except ImportError as e:
        return f"OCR需要安装依赖: pip install pdf2image pytesseract\n错误: {e}"
    except Exception as e:
        return f"OCR识别失败: {e}"


def parse_exercise_report(text):
    """
    解析运动心肺报告关键指标
    """
    data = {
        '基本信息': {},
        '心肺功能': {},
        '运动能力': {},
        '其他指标': {}
    }
    
    # 提取姓名
    name_match = re.search(r'姓名[：:]?\s*(\w+)', text)
    if name_match:
        data['基本信息']['姓名'] = name_match.group(1)
    
    # 提取性别
    gender_match = re.search(r'性别[：:]?\s*([男女])', text)
    if gender_match:
        data['基本信息']['性别'] = gender_match.group(1)
    
    # 提取年龄
    age_match = re.search(r'年龄[：:]?\s*(\d+)', text)
    if age_match:
        data['基本信息']['年龄'] = int(age_match.group(1))
    
    # 提取身高体重BMI
    height_match = re.search(r'身高[：:]?\s*(\d+\.?\d*)', text)
    if height_match:
        data['基本信息']['身高'] = float(height_match.group(1))
    
    weight_match = re.search(r'体重[：:]?\s*(\d+\.?\d*)', text)
    if weight_match:
        data['基本信息']['体重'] = float(weight_match.group(1))
    
    bmi_match = re.search(r'BMI[：:]?\s*(\d+\.?\d*)', text)
    if bmi_match:
        data['基本信息']['BMI'] = float(bmi_match.group(1))
    
    # 提取VO2peak（峰值摄氧量）
    vo2_patterns = [
        r'VO2peak[：:]?\s*(\d+\.?\d*)',
        r'峰值摄氧量[：:]?\s*(\d+\.?\d*)',
        r'最大摄氧量[：:]?\s*(\d+\.?\d*)',
        r'VO2max[：:]?\s*(\d+\.?\d*)'
    ]
    for pattern in vo2_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            data['心肺功能']['VO2peak'] = float(match.group(1))
            break
    
    # 提取AT（无氧阈）
    at_patterns = [
        r'AT[：:]?\s*(\d+\.?\d*)',
        r'无氧阈[：:]?\s*(\d+\.?\d*)',
        r'无氧阈值[：:]?\s*(\d+\.?\d*)'
    ]
    for pattern in at_patterns:
        match = re.search(pattern, text)
        if match:
            data['心肺功能']['AT'] = float(match.group(1))
            break
    
    # 提取心率数据
    hr_max_match = re.search(r'最大心率[：:]?\s*(\d+)', text)
    if hr_max_match:
        data['心肺功能']['最大心率'] = int(hr_max_match.group(1))
    
    hr_rest_match = re.search(r'静息心率[：:]?\s*(\d+)', text)
    if hr_rest_match:
        data['心肺功能']['静息心率'] = int(hr_rest_match.group(1))
    
    # 提取血压
    bp_match = re.search(r'血压[：:]?\s*(\d+)[/／](\d+)', text)
    if bp_match:
        data['其他指标']['收缩压'] = int(bp_match.group(1))
        data['其他指标']['舒张压'] = int(bp_match.group(2))
    
    # 提取诊断/结论
    diagnosis_patterns = [
        r'诊断[：:]?\s*([^\n]+)',
        r'结论[：:]?\s*([^\n]+)',
        r'检查结论[：:]?\s*([^\n]+)',
        r'诊断意见[：:]?\s*([^\n]+)'
    ]
    for pattern in diagnosis_patterns:
        match = re.search(pattern, text)
        if match:
            data['其他指标']['诊断'] = match.group(1).strip()
            break
    
    return data


def format_report_summary(data):
    """
    格式化报告摘要
    """
    lines = []
    lines.append("=" * 50)
    lines.append("运动心肺报告摘要")
    lines.append("=" * 50)
    
    # 基本信息
    if data['基本信息']:
        lines.append("\n【基本信息】")
        for key, value in data['基本信息'].items():
            lines.append(f"  {key}: {value}")
    
    # 心肺功能
    if data['心肺功能']:
        lines.append("\n【心肺功能】")
        for key, value in data['心肺功能'].items():
            lines.append(f"  {key}: {value}")
    
    # 其他指标
    if data['其他指标']:
        lines.append("\n【其他指标】")
        for key, value in data['其他指标'].items():
            lines.append(f"  {key}: {value}")
    
    lines.append("\n" + "=" * 50)
    
    return '\n'.join(lines)


def main():
    if len(sys.argv) < 2:
        print("用法: python pdf_extractor.py <pdf文件路径>")
        print("      python pdf_extractor.py <pdf文件路径> --parse")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    do_parse = '--parse' in sys.argv
    
    if not os.path.exists(pdf_path):
        print(f"错误: 文件不存在 {pdf_path}")
        sys.exit(1)
    
    # 提取文本
    text = extract_pdf_text(pdf_path)
    
    if do_parse:
        # 解析关键指标
        data = parse_exercise_report(text)
        print(format_report_summary(data))
    else:
        # 只输出文本
        print(text)


if __name__ == '__main__':
    main()
