#!/bin/bash
# med_wj.sh - 使用 curl 调用百川 API

API_KEY="sk-7466d0333b621ad2213488dd11afed4a"
QUERY="$2"

if [ -z "$QUERY" ]; then
    echo "Error: Query is empty"
    exit 1
fi

if [ "$1" = "medical" ]; then
    RESPONSE=$(curl -s -m 30 https://api.baichuan-ai.com/v1/chat/completions \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_KEY" \
        -d "{
            \"model\": \"Baichuan-M3\",
            \"messages\": [{\"role\": \"user\", \"content\": \"$QUERY\"}],
            \"temperature\": 0.3,
            \"max_tokens\": 1500
        }" 2>/dev/null)
    
    echo "$RESPONSE" | python3 -c "
import json
import sys
try:
    result = json.load(sys.stdin)
    if 'choices' in result and len(result['choices']) > 0:
        msg = result['choices'][0]['message']
        content = msg.get('content', '')
        reasoning = msg.get('reasoning_content', '')
        output = content if content and content.strip() else reasoning
        print(output)
    else:
        print('Error: Invalid response format')
        sys.exit(1)
except Exception as e:
    print(f'Error: {e}')
    sys.exit(1)
"
else
    echo "Usage: $0 medical 'query'"
    exit 1
fi
