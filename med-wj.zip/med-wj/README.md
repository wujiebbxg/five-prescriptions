# Medical and Health Assistant (med-wj)

医学与健康助手技能，提供医学、营养学、生活方式和功能医学相关问题的智能问答服务。

## 功能特性

- **医学问答**: 使用百川 AI M3 模型回答医学相关问题
- **营养学咨询**: 基于专业知识库提供营养学建议
- **生活方式指导**: 提供健康生活方式相关建议
- **功能医学**: 解答营养素和功能医学相关问题

## 使用方法

当用户询问以下类型的问题时，技能会自动被激活：

| 类别 | 类型键 | 示例问题 |
|------|--------|----------|
| 医学相关 | \`medical\` | "什么是高血压？" |
| 营养学 | \`nutrition\` | "吃什么补钙？" |
| 生活方式 | \`lifestyle\` | "如何改善睡眠？" |
| 功能医学 | \`functional_medicine\` | "维生素C的作用？" |

## 技术架构

### API 集成

1. **百川 API (Baichuan-M3)**
   - 端点: \`https://api.baichuan-ai.com/v1/chat/completions\`
   - 用于处理医学相关查询

2. **GetNote 知识库 API**
   - 端点: \`https://open-api.biji.com/getnote/openapi/knowledge/search\`
   - 用于营养学、生活方式和功能医学查询

### 文件结构

```
med-wj/
├── SKILL.md              # 技能核心文档
├── med_wj.py             # Python 脚本
├── README.md             # 本文件
└── references/           # 参考文档
    ├── baichuan_api.md   # 百川API文档
    ├── getnote_api.md    # GetNote API文档
    └── knowledge_bases.md # 知识库配置
```

## 依赖要求

- Python 3.6+
- \`requests\` 库

## 安装依赖

```bash
pip install requests
```

## 文档

详细的使用说明和 API 文档请参阅 \`SKILL.md\` 和 \`references/\` 目录下的文档。

## 许可证

本技能仅供学习和参考使用。
