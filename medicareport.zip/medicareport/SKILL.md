---
name: Medicareport
description: "医疗报告整理技能。当用户说'整理病历'、'生成病历'、'写病历'、'病历模板'等类似话语时调用，用于创建和整理临床病历、诊断报告、患者文档等医疗文书。"
---

# Medicareport - 医疗报告整理技能

## 功能

提供全面的医疗报告撰写和整理能力，包括：
- 病历报告（病例报告、CARE指南合规）
- 诊断报告（放射科、病理科、检验科）
- 临床试验报告（SAE报告、临床研究报告CSR）
- 患者文档（SOAP记录、入院记录、出院小结、会诊记录）

## 触发条件

**当用户话语包含以下关键词时自动调用：**
- "整理病历"
- "生成病历"
- "写病历"
- "病历模板"
- "创建病历"
- "病历报告"
- "医疗报告"
- "病例报告"

### 医疗HTML页面生成

**当医疗内容 + "做成html"/"生成网页" 时，优先使用本技能生成医疗风格HTML页面。**

区别于 html_wj 技能的卡片风格，本技能生成的是：
- 📋 专业医疗文档风格
- 🏥 白色背景 + 彩色边框
- 📑 清晰的诊断-处理结构
- 💊 用药清单和待办事项
- ✅ 可勾选的检查清单

**触发词组合：**
- "病历做成html"
- "医疗报告生成网页"
- "病例做成网页"
- "整理成html页面"（医疗内容）
- 任何医疗内容 + "html"/"网页"

## 使用方法

### 生成病历模板

```bash
python3 "/root/.openclaw/skills/Medicareport/scripts/generate_template.py" --type <类型> --output <输出文件>
```

**支持的模板类型：**
| 类型 | 说明 |
|------|------|
| `case_report` | 病例报告（CARE指南） |
| `soap_note` | SOAP病程记录 |
| `history_physical` | 入院记录（H&P） |
| `discharge_summary` | 出院小结 |
| `consult_note` | 会诊记录 |
| `radiology_report` | 放射科报告 |
| `pathology_report` | 病理科报告 |
| `lab_report` | 检验科报告 |
| `sae_report` | 严重不良事件报告 |
| `csr` | 临床研究报告 |

### 验证病历合规性

```bash
# 验证病例报告是否符合CARE指南
python3 "/root/.openclaw/skills/Medicareport/scripts/validate_case_report.py" <病历文件>

# 检查去标识化（HIPAA合规）
python3 "/root/.openclaw/skills/Medicareport/scripts/check_deidentification.py" <病历文件>
```

## 模板示例

### 病例报告模板
包含：标题、摘要、引言、患者信息、临床发现、时间线、诊断评估、治疗干预、随访结果、讨论、患者视角、知情同意等CARE指南要求的所有部分。

### SOAP记录模板
- **S** (Subjective) - 主观资料：患者主诉、症状描述
- **O** (Objective) - 客观资料：体征、检查结果
- **A** (Assessment) - 评估：诊断、病情分析
- **P** (Plan) - 计划：治疗方案、随访安排

### 出院小结模板
包含：入院诊断、出院诊断、入院情况、诊疗经过、出院情况、出院医嘱、随访计划等。

## 合规性支持

### HIPAA隐私保护
- 18项HIPAA标识符检查
- 去标识化验证
- Safe Harbor方法

### 监管标准
- **CARE指南** - 病例报告标准
- **ICH-E3** - 临床研究报告结构
- **CONSORT** - 临床试验报告
- **ACR** - 放射科报告标准
- **CAP** - 病理科报告标准

## 使用示例

```bash
# 生成病例报告模板
python3 "/root/.openclaw/skills/Medicareport/scripts/generate_template.py" --type case_report --output case_report.md

# 生成SOAP记录模板
python3 "/root/.openclaw/skills/Medicareport/scripts/generate_template.py" --type soap_note --output soap_note.md

# 生成出院小结模板
python3 "/root/.openclaw/skills/Medicareport/scripts/generate_template.py" --type discharge_summary --output discharge.md
```

## 注意事项

- 所有病历文档需遵守患者隐私保护法规
- 病例报告发表前需获得患者知情同意
- 确保去除所有18项HIPAA标识符
- 使用标准医学术语和缩写

## 参考标准

- CARE Guidelines (CAse REport)
- ICH-E3 Clinical Study Reports
- CONSORT Statement
- HIPAA Privacy Rule
- ACR Practice Parameters
- CAP Cancer Protocols
