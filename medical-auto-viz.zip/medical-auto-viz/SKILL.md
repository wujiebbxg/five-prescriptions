---
name: medical-auto-viz
description: "医疗数据自动分析与ECharts可视化一体化技能。自动识别检验数据类型（血脂/心电图/生化），完成医学计算后生成交互式图表报告。支持基线特征表(Table 1)生成。"
---

# Medical Auto Viz - 医疗数据自动可视化

## 功能

自动分析医疗检验数据（CSV/Excel），识别数据类型，生成ECharts交互式图表报告。

### 支持的数据类型

| 类型 | 指标 | 说明 |
|:---|:---|:---|
| **血脂** | TC, TG, HDL, LDL | 总胆固醇、甘油三酯等 |
| **心电图** | RR_interval, heart_rate, QRS | 心率、波形分析 |
| **生化** | ALT, AST, CREA, BUN, GLU | 肝肾功能、血糖 |
| **生命体征** | BP, HR, SpO2, Temp | 血压、心率、血氧、体温 |

---

## 📊 Table 1 基线特征表生成

医学研究中，Table 1 是论文必备的基线特征表。使用 Python `tableone` 包一键生成：

### 安装
```bash
pip install tableone
```

### 使用示例
```python
from tableone import TableOne
import pandas as pd

# 加载临床数据
df = pd.read_csv('clinical_data.csv')

# 定义变量
columns = ['age', 'gender', 'bmi', 'systolic_bp', 'diabetes']
categorical = ['gender', 'diabetes']  # 分类变量
groupby = 'treatment_group'  # 分组变量

# 生成 Table 1
table1 = TableOne(
    df, 
    columns=columns, 
    categorical=categorical,
    groupby=groupby,
    pval=True,   # 计算 p 值
    smd=True     # 计算标准化均数差
)

# 输出表格
print(table1.tabulate(tablefmt='github'))

# 导出 CSV
table1.to_csv('table1.csv')
```

### 输出示例
```
                          Stratified by treatment
                           实验组           对照组         p      SMD
  n                            100            100
  age (mean (SD))          55.4 (12.7)    54.1 (11.5)   0.473  0.102
  gender, n (%)                                                    
     女                       60 (60.0)      62 (62.0)   0.885  0.041
     男                       40 (40.0)      38 (38.0)
  bmi (mean (SD))          24.3 (3.6)     24.2 (3.5)    0.978  0.004
```

### 功能特点
- **连续变量**: 自动显示 均值±SD 或 中位数[IQR]
- **分类变量**: 显示 n (%)
- **组间比较**: 自动计算 p 值
- **平衡性评估**: 标准化均数差 (SMD)
- **多格式导出**: CSV, Excel, LaTeX

---

## 使用方法

### 命令触发

```
分析并可视化 [文件路径]
生成血脂报告 [文件路径]
生成心电图报告 [文件路径]
生成Table1 [文件路径] --groupby [分组变量]
```

### Python API

```python
from medical_auto_viz import analyze_and_visualize

# 自动识别
result = analyze_and_visualize('patient_data.csv')

# 指定类型
result = analyze_and_visualize('lipid.csv', type='lipid')
```

## 输出

- **HTML报告** - 交互式ECharts图表
- **JSON数据** - 原始分析数据
- **医学建议** - 基于参考范围的自动建议

## 配置参数

| 参数 | 选项 | 默认 |
|:---|:---|:---|
| analysis_type | auto/lipid/ecg/biochem/vitals | auto |
| output_format | html/pdf/json | html |
| chart_theme | medical-blue/medical-green | medical-blue |
| include_advice | true/false | true |
