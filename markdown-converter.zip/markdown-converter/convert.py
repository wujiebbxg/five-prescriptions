#!/usr/bin/env python3
"""
Markdown Converter - Convert between Markdown and other formats
"""

import argparse
import sys
import os
import json
import re

def md_to_html(markdown_text, title=""):
    """Convert Markdown to HTML"""
    try:
        import markdown
        md = markdown.Markdown(extensions=['extra', 'codehilite', 'tables'])
        html_content = md.convert(markdown_text)
        
        full_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title or 'Document'}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 40px auto; padding: 0 20px; line-height: 1.6; }}
        code {{ background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }}
        pre {{ background: #f4f4f4; padding: 16px; overflow-x: auto; border-radius: 6px; }}
        pre code {{ padding: 0; background: none; }}
        blockquote {{ border-left: 4px solid #ddd; margin: 0; padding-left: 16px; color: #666; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background: #f4f4f4; }}
    </style>
</head>
<body>
{html_content}
</body>
</html>"""
        return full_html
    except ImportError:
        # Fallback simple conversion
        html = markdown_text
        # Headers
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        # Bold and italic
        html = re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', html)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        # Code
        html = re.sub(r'`(.+?)`', r'<code>\1</code>', html)
        # Links
        html = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', html)
        # Paragraphs
        paragraphs = html.split('\n\n')
        html = '\n\n'.join(f'<p>{p}</p>' if not p.startswith('<') else p for p in paragraphs)
        return html

def html_to_md(html_text):
    """Convert HTML to Markdown"""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_text, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()
        
        md = []
        for elem in soup.body.descendants if soup.body else soup.descendants:
            if elem.name:
                text = elem.get_text(strip=True)
                if not text:
                    continue
                    
                if elem.name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                    level = int(elem.name[1])
                    md.append(f"{'#' * level} {text}\n")
                elif elem.name == 'p':
                    md.append(f"{text}\n")
                elif elem.name == 'strong' or elem.name == 'b':
                    md.append(f"**{text}**")
                elif elem.name == 'em' or elem.name == 'i':
                    md.append(f"*{text}*")
                elif elem.name == 'code':
                    md.append(f"`{text}`")
                elif elem.name == 'a':
                    href = elem.get('href', '')
                    md.append(f"[{text}]({href})")
                elif elem.name == 'li':
                    md.append(f"- {text}")
                elif elem.name == 'br':
                    md.append('\n')
        
        return '\n'.join(md)
    except ImportError:
        # Simple fallback
        text = re.sub(r'<[^>]+>', '', html_text)
        return text

def md_to_json(markdown_text):
    """Convert Markdown to structured JSON"""
    lines = markdown_text.split('\n')
    structure = {
        "title": "",
        "headers": [],
        "paragraphs": [],
        "lists": [],
        "code_blocks": []
    }
    
    current_list = []
    in_code_block = False
    code_content = []
    code_lang = ""
    
    for line in lines:
        # Title (first h1)
        if line.startswith('# ') and not structure["title"]:
            structure["title"] = line[2:].strip()
        
        # Headers
        if line.startswith('#'):
            level = len(line) - len(line.lstrip('#'))
            structure["headers"].append({
                "level": level,
                "text": line.lstrip('#').strip()
            })
        
        # Code blocks
        elif line.startswith('```'):
            if in_code_block:
                structure["code_blocks"].append({
                    "language": code_lang,
                    "code": '\n'.join(code_content)
                })
                in_code_block = False
                code_content = []
                code_lang = ""
            else:
                in_code_block = True
                code_lang = line[3:].strip()
        
        elif in_code_block:
            code_content.append(line)
        
        # List items
        elif line.strip().startswith('- ') or line.strip().startswith('* '):
            current_list.append(line.strip()[2:])
        
        elif current_list and not line.strip().startswith('- ') and not line.strip().startswith('* '):
            structure["lists"].append(current_list)
            current_list = []
        
        # Paragraphs
        elif line.strip():
            structure["paragraphs"].append(line.strip())
    
    if current_list:
        structure["lists"].append(current_list)
    
    return json.dumps(structure, ensure_ascii=False, indent=2)

def convert_file(input_path, output_path, from_fmt, to_fmt, title=""):
    """Convert file from one format to another"""
    # Read input
    with open(input_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Convert
    if from_fmt == 'md' and to_fmt == 'html':
        result = md_to_html(content, title)
    elif from_fmt == 'html' and to_fmt == 'md':
        result = html_to_md(content)
    elif from_fmt == 'md' and to_fmt == 'json':
        result = md_to_json(content)
    elif from_fmt == 'txt' and to_fmt == 'md':
        # Simple text to markdown
        lines = content.split('\n')
        result = '\n\n'.join(line.strip() for line in lines if line.strip())
    else:
        # Try using pandoc for other conversions
        try:
            import pypandoc
            result = pypandoc.convert_text(content, to_fmt, format=from_fmt)
        except:
            result = f"Conversion from {from_fmt} to {to_fmt} requires pandoc. Please install: apt-get install pandoc"
    
    # Write output
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(result)
    
    return output_path

def main():
    parser = argparse.ArgumentParser(description='Markdown Converter')
    parser.add_argument('--from', dest='from_fmt', required=True, 
                        choices=['md', 'html', 'txt', 'docx', 'pdf'],
                        help='Source format')
    parser.add_argument('--to', dest='to_fmt', required=True,
                        choices=['md', 'html', 'json', 'txt', 'docx', 'pdf'],
                        help='Target format')
    parser.add_argument('--input', help='Input content as string')
    parser.add_argument('--input-file', help='Input file path')
    parser.add_argument('--output', required=True, help='Output file path')
    parser.add_argument('--title', default='', help='Document title')
    
    args = parser.parse_args()
    
    # Get input content
    if args.input_file:
        with open(args.input_file, 'r', encoding='utf-8') as f:
            content = f.read()
    elif args.input:
        content = args.input
    else:
        print("Error: Either --input or --input-file must be provided")
        sys.exit(1)
    
    # Convert
    if args.from_fmt == 'md' and args.to_fmt == 'html':
        result = md_to_html(content, args.title)
    elif args.from_fmt == 'html' and args.to_fmt == 'md':
        result = html_to_md(content)
    elif args.from_fmt == 'md' and args.to_fmt == 'json':
        result = md_to_json(content)
    elif args.from_fmt == 'txt' and args.to_fmt == 'md':
        lines = content.split('\n')
        result = '\n\n'.join(line.strip() for line in lines if line.strip())
    else:
        # For other conversions, try pandoc
        try:
            import pypandoc
            result = pypandoc.convert_text(content, args.to_fmt, format=args.from_fmt)
        except ImportError:
            result = f"Error: Conversion from {args.from_fmt} to {args.to_fmt} requires pandoc.\n"
            result += "Please install: apt-get install pandoc\n"
            result += "Or: pip install pypandoc"
        except Exception as e:
            result = f"Error during conversion: {e}"
    
    # Write output
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(result)
    
    print(f"Converted successfully: {args.output}")

if __name__ == '__main__':
    main()
