#!/usr/bin/env python3
"""
Medical Auto Viz - 命令行入口
"""

import sys
import os

# 添加技能目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from medical_viz_core import analyze_and_visualize

def main():
    """主入口函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='医疗数据自动可视化')
    parser.add_argument('file', help='数据文件路径 (CSV/Excel)')
    parser.add_argument('--type', '-t', default='auto', 
                       choices=['auto', 'lipid', 'ecg', 'biochem', 'vitals'],
                       help='分析类型 (默认: 自动识别)')
    parser.add_argument('--format', '-f', default='html',
                       choices=['html', 'json'],
                       help='输出格式 (默认: html)')
    parser.add_argument('--theme', default='medical-blue',
                       choices=['medical-blue', 'medical-green'],
                       help='图表主题 (默认: medical-blue)')
    parser.add_argument('--no-advice', action='store_true',
                       help='不包含医学建议')
    
    args = parser.parse_args()
    
    try:
        result = analyze_and_visualize(
            file_path=args.file,
            analysis_type=args.type,
            output_format=args.format,
            chart_theme=args.theme,
            include_advice=not args.no_advice
        )
        
        print(f"\n✅ 分析完成!")
        print(f"📄 输出文件: {result.get('output_path', 'N/A')}")
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
