#!/bin/bash
# 百川模型调用脚本（使用 curl）

QUERY="$1"
if [ -z "$QUERY" ]; then
    echo "Usage: $0 'query'"
    exit 1
fi

curl -s -X POST https://api.baichuan-ai.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-7466d0333b621ad2213488dd11afed4a" \
  -d "{
    \"model\": \"Baichuan-M3\",
    \"messages\": [{\"role\": \"user\", \"content\": \"$QUERY\"}],
    \"temperature\": 0.3,
    \"max_tokens\": 2048
  }" \
  --connect-timeout 10 \
  --max-time 30 | python3 -c "
import json
import sys
try:
    result = json.load(sys.stdin)
    if 'choices' in result and len(result['choices']) > 0:
        msg = result['choices'][0]['message']
        content = msg.get('content', '')
        reasoning = msg.get('reasoning_content', '')
        print(content if content else reasoning)
    else:
        print('Error: Unexpected response format')
except Exception as e:
    print(f'Error: {e}')
"
