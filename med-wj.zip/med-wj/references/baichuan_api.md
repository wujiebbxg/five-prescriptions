# Baichuan API Documentation

## Overview

Baichuan AI (百川智能) provides advanced AI models for various applications. The med-wj skill uses Baichuan-M3 model for medical-related queries.

## API Endpoint

```
POST https://api.baichuan-ai.com/v1/chat/completions
```

## Authentication

Use Bearer token authentication:

```http
Authorization: Bearer sk-7466d0333b621ad2213488dd11afed4a
```

## Request Format

```http
POST https://api.baichuan-ai.com/v1/chat/completions
Content-Type: application/json
Authorization: Bearer {apiKey}

{
  "model": "Baichuan-M3",
  "messages": [
    {
      "role": "user",
      "content": "Your question here"
    }
  ],
  "temperature": 0.3,
  "top_p": 0.85,
  "max_tokens": 2048,
  "tools": [
    {
      "type": "web_search",
      "web_search": {
        "enable": false
      }
    }
  ],
  "stream": false
}
```

## Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| model | string | - | Model name: \`Baichuan-M3\` |
| messages | array | - | List of message objects with \`role\` and \`content\` |
| temperature | float | 0.3 | Controls randomness (0.0 - 1.0) |
| top_p | float | 0.85 | Nucleus sampling parameter |
| max_tokens | int | 2048 | Maximum tokens to generate |
| stream | boolean | false | Enable streaming response |
| tools | array | - | Optional tools (web_search disabled) |

## Response Format

```json
{
  "choices": [
    {
      "message": {
        "content": "AI response content here"
      }
    }
  ]
}
```

## cURL Example

```bash
curl -X POST 'https://api.baichuan-ai.com/v1/chat/completions' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer sk-7466d0333b621ad2213488dd11afed4a' \
  -d '{
    "model": "Baichuan-M3",
    "messages": [{ "role": "user", "content": "什么是高血压？" }],
    "temperature": 0.3,
    "top_p": 0.85,
    "max_tokens": 2048,
    "tools": [
      {
        "type": "web_search",
        "web_search": {
          "enable": false
        }
      }
    ],
    "stream": false
  }'
```

## Notes

- The web_search tool is currently disabled in this implementation
- Temperature of 0.3 provides more focused, deterministic responses
- Max tokens set to 2048 for detailed medical answers
