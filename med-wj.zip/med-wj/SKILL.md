---
name: med-wj
description: "Medical and Health assistant. Invoke when user asks about Medicine, Nutrition, Lifestyle, or Functional Medicine."
---

# Medical and Health Assistant (med-wj)

## Overview

This skill handles queries related to Medicine, Nutrition, Lifestyle, and Functional Medicine by accessing specific AI models and knowledge bases.

**Key Features:**
- Medical queries: Powered by Baichuan-M3 AI model
- Nutrition, Lifestyle, Functional Medicine: Powered by GetNote knowledge base search

## When to use

Use this skill when a user asks questions about:
- Medical and health topics (医学相关)
- Nutrition and diet (营养学)
- Lifestyle and wellness (生活方式)
- Nutrients and functional medicine (营养素或功能医学)

## Workflow

### Determining the Query Type

First, determine which category the user's question falls into:

| Category | Type Key | Data Source |
|----------|----------|-------------|
| Medical | `medical` | Baichuan-M3 AI Model |
| Nutrition | `nutrition` | GetNote Knowledge Base |
| Lifestyle | `lifestyle` | GetNote Knowledge Base |
| Functional Medicine | `functional_medicine` | GetNote Knowledge Base |

### Executing the Query

Use the Python helper script to execute the query:

```bash
python "/root/.openclaw/skills/med-wj/med_wj.py" --type <TYPE> --query "<USER_QUERY>"
```

**Parameters:**
- `--type`: The category key (medical, nutrition, lifestyle, functional_medicine)
- `--query`: The user's exact question (use quotes if the query contains spaces)

### Returning the Result

The script outputs the answer from the corresponding AI model or knowledge base. Present this output directly to the user.

## Examples

### Medical Query

**User:** "什么是高血压？"

**Action:**
```bash
python "/root/.openclaw/skills/med-wj/med_wj.py" --type medical --query "什么是高血压？"
```

### Nutrition Query

**User:** "吃什么补钙？"

**Action:**
```bash
python "/root/.openclaw/skills/med-wj/med_wj.py" --type nutrition --query "吃什么补钙？"
```

### Lifestyle Query

**User:** "如何改善睡眠？"

**Action:**
```bash
python "/root/.openclaw/skills/med-wj/med_wj.py" --type lifestyle --query "如何改善睡眠？"
```

### Functional Medicine Query

**User:** "维生素C的作用？"

**Action:**
```bash
python "/root/.openclaw/skills/med-wj/med_wj.py" --type functional_medicine --query "维生素C的作用？"
```

## API Details

### Baichuan API (for Medical Queries)

| Parameter | Value |
|-----------|-------|
| Provider | Baichuan AI (百川智能) |
| Model | Baichuan-M3 |
| Endpoint | https://api.baichuan-ai.com/v1/chat/completions |
| Temperature | 0.3 |
| Top P | 0.85 |
| Max Tokens | 2048 |

### GetNote API (for Nutrition, Lifestyle, Functional Medicine)

| Parameter | Value |
|-----------|-------|
| Endpoint | https://open-api.biji.com/getnote/openapi/knowledge/search |
| Deep Seek | Enabled |

### Knowledge Base IDs

| Category | Knowledge Base ID |
|----------|-------------------|
| Nutrition | w0E6PpEJ |
| Lifestyle | ww0E73xyn |
| Functional Medicine | zJKPQaWn |

## Error Handling

If the script execution fails:

1. **Check the error message** - The script outputs specific error details
2. **Verify network connectivity** - Ensure internet connection is active
3. **Check API configuration** - Verify API keys are valid
4. **Retry the query** - Some API calls may fail temporarily

---

## References

For detailed API documentation and configuration, see:
- `references/baichuan_api.md` - Baichuan API details
- `references/getnote_api.md` - GetNote API documentation
- `references/knowledge_bases.md` - Knowledge base configuration

## Notes

- API keys are pre-configured in the script
- Knowledge base searches use deep seek for better results
- The script handles JSON response parsing automatically
- Ensure quotes are properly escaped when passing queries with special characters
