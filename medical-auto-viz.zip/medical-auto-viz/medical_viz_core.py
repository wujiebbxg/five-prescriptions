#!/usr/bin/env python3
"""
Medical Auto Viz - 医疗数据自动可视化核心模块
"""

import pandas as pd
import numpy as np
import json
import sys
from pathlib import Path
from datetime import datetime

# 医学指标库
MEDICAL_INDICATORS = {
    'lipid': {
        'markers': ['TC', 'TG', 'HDL', 'LDL', 'CHO', 'TRIG', '总胆固醇', '甘油三酯', '高密度脂蛋白', '低密度脂蛋白'],
        'units': 'mmol/L',
        'reference_ranges': {
            'TC': {'max': 5.2, 'label': '总胆固醇'},
            'TG': {'max': 1.7, 'label': '甘油三酯'},
            'LDL': {'max': 3.4, 'label': '低密度脂蛋白'},
            'HDL': {'min': 1.0, 'label': '高密度脂蛋白'}
        }
    },
    'ecg': {
        'markers': ['RR_interval', 'voltage', 'heart_rate', 'QRS', '心率', '心律'],
        'units': 'mV/ms',
        'reference_ranges': {
            'heart_rate': {'min': 60, 'max': 100, 'label': '心率'},
        }
    },
    'biochem': {
        'markers': ['ALT', 'AST', 'CREA', 'BUN', 'GLU', '谷丙转氨酶', '肌酐', '尿素氮', '血糖'],
        'units': 'U/L或mmol/L',
        'reference_ranges': {
            'ALT': {'max': 40, 'label': '谷丙转氨酶'},
            'AST': {'max': 40, 'label': '谷草转氨酶'},
            'CREA': {'max': 133, 'label': '肌酐'},
            'GLU': {'min': 3.9, 'max': 6.1, 'label': '空腹血糖'}
        }
    },
    'vitals': {
        'markers': ['BP', 'HR', 'SpO2', 'Temp', '血压', '心率', '血氧', '体温'],
        'units': 'mmHg/bpm/%/°C',
        'reference_ranges': {
            'SBP': {'min': 90, 'max': 140, 'label': '收缩压'},
            'DBP': {'min': 60, 'max': 90, 'label': '舒张压'},
            'HR': {'min': 60, 'max': 100, 'label': '心率'},
            'SpO2': {'min': 95, 'label': '血氧饱和度'},
        }
    }
}

def auto_detect_type(df):
    """自动识别数据类型"""
    columns = [str(col).upper() for col in df.columns]
    
    scores = {}
    for data_type, config in MEDICAL_INDICATORS.items():
        score = 0
        for marker in config['markers']:
            if any(marker.upper() in col for col in columns):
                score += 1
        scores[data_type] = score
    
    # 返回得分最高的类型
    if max(scores.values()) > 0:
        return max(scores, key=scores.get)
    return 'unknown'

def analyze_lipid(df):
    """血脂分析"""
    results = {}
    markers = MEDICAL_INDICATORS['lipid']['reference_ranges']
    
    for key, config in markers.items():
        # 查找对应的列
        col = None
        for c in df.columns:
            if key in str(c).upper() or config['label'] in str(c):
                col = c
                break
        
        if col and not df[col].empty:
            value = float(df[col].iloc[0])
            status = 'normal'
            
            if 'max' in config and value > config['max']:
                status = 'high'
            elif 'min' in config and value < config['min']:
                status = 'low'
            
            results[key] = {
                'value': value,
                'unit': 'mmol/L',
                'status': status,
                'label': config['label'],
                'reference': config
            }
    
    return results

def analyze_biochem(df):
    """生化分析"""
    results = {}
    markers = MEDICAL_INDICATORS['biochem']['reference_ranges']
    
    for key, config in markers.items():
        col = None
        for c in df.columns:
            if key in str(c).upper() or config['label'] in str(c):
                col = c
                break
        
        if col and not df[col].empty:
            value = float(df[col].iloc[0])
            status = 'normal'
            
            if 'max' in config and value > config['max']:
                status = 'high'
            elif 'min' in config and value < config['min']:
                status = 'low'
            
            results[key] = {
                'value': value,
                'unit': 'U/L' if '转氨酶' in config['label'] else 'μmol/L',
                'status': status,
                'label': config['label'],
                'reference': config
            }
    
    return results

def generate_echarts_config(analysis_result, data_type):
    """生成ECharts配置"""
    charts = []
    
    if data_type == 'lipid':
        # 血脂柱状图
        categories = []
        values = []
        colors = []
        
        for key, data in analysis_result.items():
            categories.append(data['label'])
            values.append(data['value'])
            colors.append('#ef4444' if data['status'] == 'high' else '#22c55e')
        
        chart = {
            'type': 'bar',
            'title': '血脂指标分析',
            'xAxis': categories,
            'series': [{
                'data': values,
                'itemStyle': {'color': colors}
            }]
        }
        charts.append(chart)
    
    elif data_type == 'biochem':
        # 生化指标图
        categories = []
        values = []
        
        for key, data in analysis_result.items():
            categories.append(data['label'])
            values.append({
                'value': data['value'],
                'status': data['status']
            })
        
        chart = {
            'type': 'bar',
            'title': '生化指标分析',
            'xAxis': categories,
            'series': [{'data': [v['value'] for v in values]}]
        }
        charts.append(chart)
    
    return charts

def generate_html_report(patient_info, analysis, charts, theme='medical-blue'):
    """生成HTML报告"""
    
    # 根据主题选择配色
    themes = {
        'medical-blue': {
            'primary': '#3b82f6',
            'secondary': '#60a5fa',
            'bg': '#0f172a',
            'card': '#1e293b'
        },
        'medical-green': {
            'primary': '#22c55e',
            'secondary': '#4ade80',
            'bg': '#052e16',
            'card': '#14532d'
        }
    }
    
    t = themes.get(theme, themes['medical-blue'])
    
    # 生成状态标签
    def status_badge(status):
        colors = {
            'normal': 'bg-green-500',
            'high': 'bg-red-500',
            'low': 'bg-yellow-500'
        }
        labels = {
            'normal': '正常',
            'high': '偏高',
            'low': '偏低'
        }
        return f'<span class="{colors.get(status, "bg-gray-500")} text-white text-xs px-2 py-1 rounded">{labels.get(status, "未知")}</span>'
    
    html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>医疗数据分析报告</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
    <style>
        body {{ background: {t['bg']}; color: white; font-family: 'Noto Sans SC', sans-serif; }}
        .card {{ background: {t['card']}; border-radius: 12px; padding: 20px; margin: 16px 0; }}
        .indicator {{ display: flex; justify-content: space-between; align-items: center; padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.1); }}
    </style>
</head>
<body class="min-h-screen p-8">
    <div class="max-w-4xl mx-auto">
        <header class="text-center mb-8">
            <h1 class="text-3xl font-bold" style="color: {t['primary']}">医疗数据分析报告</h1>
            <p class="text-gray-400 mt-2">生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
        </header>
        
        <div class="card">
            <h2 class="text-xl font-semibold mb-4" style="color: {t['secondary']}">分析结果</h2>
"""
    
    # 添加指标列表
    for key, data in analysis.items():
        html += f"""
            <div class="indicator">
                <div>
                    <span class="font-medium">{data['label']}</span>
                    <span class="text-gray-400 text-sm ml-2">{data['value']} {data['unit']}</span>
                </div>
                {status_badge(data['status'])}
            </div>
"""
    
    html += """
        </div>
        
        <div class="card">
            <h2 class="text-xl font-semibold mb-4">可视化图表</h2>
            <div id="chart" style="width: 100%; height: 400px;"></div>
        </div>
    </div>
    
    <script>
        // ECharts 配置
        var chart = echarts.init(document.getElementById('chart'));
        var option = {
            backgroundColor: 'transparent',
            title: { text: '指标对比', textStyle: { color: '#fff' } },
            xAxis: { type: 'category', data: """ + str([c for c in analysis.keys()]) + """, axisLabel: { color: '#fff' } },
            yAxis: { type: 'value', axisLabel: { color: '#fff' } },
            series: [{
                data: """ + str([d['value'] for d in analysis.values()]) + """,
                type: 'bar',
                itemStyle: {
                    color: function(params) {
                        var status = """ + str([d['status'] for d in analysis.values()]) + """[params.dataIndex];
                        return status === 'high' ? '#ef4444' : status === 'low' ? '#eab308' : '#22c55e';
                    }
                }
            }]
        };
        chart.setOption(option);
    </script>
</body>
</html>
"""
    
    return html

def analyze_bp(df):
    """血压分析"""
    results = {}
    
    # 计算平均值
    sbp_avg = df['收缩压'].mean() if '收缩压' in df.columns else df['SBP'].mean() if 'SBP' in df.columns else 0
    dbp_avg = df['舒张压'].mean() if '舒张压' in df.columns else df['DBP'].mean() if 'DBP' in df.columns else 0
    
    # 判断血压状态
    def get_bp_status(sbp, dbp):
        if sbp >= 140 or dbp >= 90:
            return 'high'
        elif sbp >= 120 or dbp >= 80:
            return 'elevated'
        else:
            return 'normal'
    
    status = get_bp_status(sbp_avg, dbp_avg)
    
    results['SBP'] = {
        'value': round(sbp_avg, 1),
        'unit': 'mmHg',
        'status': 'high' if sbp_avg >= 140 else 'elevated' if sbp_avg >= 120 else 'normal',
        'label': '收缩压',
        'reference': {'min': 90, 'max': 140}
    }
    
    results['DBP'] = {
        'value': round(dbp_avg, 1),
        'unit': 'mmHg',
        'status': 'high' if dbp_avg >= 90 else 'elevated' if dbp_avg >= 80 else 'normal',
        'label': '舒张压',
        'reference': {'min': 60, 'max': 90}
    }
    
    # 添加趋势分析
    if len(df) > 1:
        sbp_trend = 'rising' if df['收缩压'].iloc[-1] > df['收缩压'].iloc[0] else 'falling'
        dbp_trend = 'rising' if df['舒张压'].iloc[-1] > df['舒张压'].iloc[0] else 'falling'
        results['trend'] = {
            'sbp': sbp_trend,
            'dbp': dbp_trend,
            'sbp_change': int(df['收缩压'].iloc[-1] - df['收缩压'].iloc[0]),
            'dbp_change': int(df['舒张压'].iloc[-1] - df['舒张压'].iloc[0])
        }
    
    return results

def generate_bp_echarts(df):
    """生成血压趋势图配置"""
    dates = df['日期'].tolist() if '日期' in df.columns else [f'第{i+1}天' for i in range(len(df))]
    sbp = df['收缩压'].tolist() if '收缩压' in df.columns else df['SBP'].tolist()
    dbp = df['舒张压'].tolist() if '舒张压' in df.columns else df['DBP'].tolist()
    
    chart = {
        'type': 'line',
        'title': '血压变化趋势',
        'xAxis': dates,
        'series': [
            {
                'name': '收缩压',
                'data': sbp,
                'type': 'line',
                'smooth': True,
                'itemStyle': {'color': '#ef4444'},
                'markLine': {
                    'data': [{'yAxis': 140, 'label': {'formatter': '上限'}}],
                    'lineStyle': {'color': '#ef4444', 'type': 'dashed'}
                }
            },
            {
                'name': '舒张压',
                'data': dbp,
                'type': 'line',
                'smooth': True,
                'itemStyle': {'color': '#3b82f6'},
                'markLine': {
                    'data': [{'yAxis': 90, 'label': {'formatter': '上限'}}],
                    'lineStyle': {'color': '#3b82f6', 'type': 'dashed'}
                }
            }
        ]
    }
    
    return [chart]

def generate_bp_html(df, analysis, chart_theme='medical-blue'):
    """生成血压分析HTML报告"""
    
    themes = {
        'medical-blue': {'primary': '#3b82f6', 'secondary': '#60a5fa', 'bg': '#0f172a', 'card': '#1e293b'},
        'medical-green': {'primary': '#22c55e', 'secondary': '#4ade80', 'bg': '#052e16', 'card': '#14532d'}
    }
    
    t = themes.get(chart_theme, themes['medical-blue'])
    
    dates = df['日期'].tolist() if '日期' in df.columns else [f'第{i+1}天' for i in range(len(df))]
    sbp = df['收缩压'].tolist() if '收缩压' in df.columns else df['SBP'].tolist()
    dbp = df['舒张压'].tolist() if '舒张压' in df.columns else df['DBP'].tolist()
    
    def status_badge(status):
        colors = {'normal': 'bg-green-500', 'elevated': 'bg-yellow-500', 'high': 'bg-red-500'}
        labels = {'normal': '正常', 'elevated': '偏高', 'high': '高血压'}
        return f'<span class="{colors.get(status, "bg-gray-500")} text-white text-xs px-2 py-1 rounded">{labels.get(status, "未知")}</span>'
    
    trend_info = analysis.get('trend', {})
    trend_html = ''
    if trend_info:
        sbp_change = trend_info.get('sbp_change', 0)
        dbp_change = trend_info.get('dbp_change', 0)
        trend_html = f'''
        <div class="card">
            <h2 class="text-xl font-semibold mb-4" style="color: {t['secondary']}">趋势分析</h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="bg-white/5 rounded-lg p-4">
                    <div class="text-gray-400 text-sm">收缩压变化</div>
                    <div class="text-2xl font-bold" style="color: {'#ef4444' if sbp_change > 0 else '#22c55e'}">
                        {'+' if sbp_change > 0 else ''}{sbp_change} mmHg
                    </div>
                </div>
                <div class="bg-white/5 rounded-lg p-4">
                    <div class="text-gray-400 text-sm">舒张压变化</div>
                    <div class="text-2xl font-bold" style="color: {'#ef4444' if dbp_change > 0 else '#22c55e'}">
                        {'+' if dbp_change > 0 else ''}{dbp_change} mmHg
                    </div>
                </div>
            </div>
        </div>
        '''
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>血压监测报告</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
    <style>
        body {{ background: {t['bg']}; color: white; font-family: 'Noto Sans SC', sans-serif; }}
        .card {{ background: {t['card']}; border-radius: 12px; padding: 20px; margin: 16px 0; }}
        .indicator {{ display: flex; justify-content: space-between; align-items: center; padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.1); }}
    </style>
</head>
<body class="min-h-screen p-8">
    <div class="max-w-4xl mx-auto">
        <header class="text-center mb-8">
            <h1 class="text-3xl font-bold" style="color: {t['primary']}">血压监测报告</h1>
            <p class="text-gray-400 mt-2">监测周期: {dates[0]} 至 {dates[-1]}</p>
            <p class="text-gray-400">生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
        </header>
        
        <div class="card">
            <h2 class="text-xl font-semibold mb-4" style="color: {t['secondary']}">平均血压</h2>
            
            <div class="indicator">
                <div>
                    <span class="font-medium">收缩压 (平均)</span>
                    <span class="text-gray-400 text-sm ml-2">{analysis['SBP']['value']} mmHg</span>
                </div>
                {status_badge(analysis['SBP']['status'])}
            </div>
            
            <div class="indicator">
                <div>
                    <span class="font-medium">舒张压 (平均)</span>
                    <span class="text-gray-400 text-sm ml-2">{analysis['DBP']['value']} mmHg</span>
                </div>
                {status_badge(analysis['DBP']['status'])}
            </div>
        </div>
        
        {trend_html}
        
        <div class="card">
            <h2 class="text-xl font-semibold mb-4">血压趋势图</h2>
            <div id="chart" style="width: 100%; height: 400px;"></div>
        </div>
        
        <div class="card">
            <h2 class="text-xl font-semibold mb-4" style="color: {t['secondary']}">参考标准</h2>
            <div class="grid grid-cols-3 gap-4 text-center text-sm">
                <div class="bg-green-500/20 rounded-lg p-3">
                    <div class="text-green-400 font-semibold">正常</div>
                    <div class="text-gray-300">&lt;120/80</div>
                </div>
                <div class="bg-yellow-500/20 rounded-lg p-3">
                    <div class="text-yellow-400 font-semibold">偏高</div>
                    <div class="text-gray-300">120-139/80-89</div>
                </div>
                <div class="bg-red-500/20 rounded-lg p-3">
                    <div class="text-red-400 font-semibold">高血压</div>
                    <div class="text-gray-300">≥140/90</div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        var chart = echarts.init(document.getElementById('chart'));
        var option = {{
            backgroundColor: 'transparent',
            legend: {{ data: ['收缩压', '舒张压'], textStyle: {{ color: '#fff' }} }},
            grid: {{ left: '3%', right: '4%', bottom: '3%', containLabel: true }},
            xAxis: {{ 
                type: 'category', 
                data: {dates}, 
                axisLabel: {{ color: '#fff', rotate: 45 }}
            }},
            yAxis: {{ 
                type: 'value', 
                name: 'mmHg',
                nameTextStyle: {{ color: '#fff' }},
                axisLabel: {{ color: '#fff' }},
                splitLine: {{ lineStyle: {{ color: 'rgba(255,255,255,0.1)' }} }}
            }},
            series: [
                {{
                    name: '收缩压',
                    data: {sbp},
                    type: 'line',
                    smooth: true,
                    itemStyle: {{ color: '#ef4444' }},
                    areaStyle: {{ color: 'rgba(239,68,68,0.1)' }},
                    markLine: {{
                        data: [{{yAxis: 140, label: {{formatter: '上限', color: '#ef4444'}}}}],
                        lineStyle: {{ color: '#ef4444', type: 'dashed' }}
                    }}
                }},
                {{
                    name: '舒张压',
                    data: {dbp},
                    type: 'line',
                    smooth: true,
                    itemStyle: {{ color: '#3b82f6' }},
                    areaStyle: {{ color: 'rgba(59,130,246,0.1)' }},
                    markLine: {{
                        data: [{{yAxis: 90, label: {{formatter: '上限', color: '#3b82f6'}}}}],
                        lineStyle: {{ color: '#3b82f6', type: 'dashed' }}
                    }}
                }}
            ]
        }};
        chart.setOption(option);
    </script>
</body>
</html>"""
    
    return html

def analyze_and_visualize(file_path, analysis_type='auto', output_format='html', chart_theme='medical-blue', include_advice=True):
    """
    主函数：分析并可视化医疗数据
    """
    
    # 读取数据
    if file_path.endswith('.csv'):
        df = pd.read_csv(file_path)
    elif file_path.endswith(('.xlsx', '.xls')):
        df = pd.read_excel(file_path)
    else:
        raise ValueError("不支持的文件格式，请使用 CSV 或 Excel")
    
    # 自动识别类型
    if analysis_type == 'auto':
        analysis_type = auto_detect_type(df)
    
    print(f"[INFO] 检测到数据类型: {analysis_type}")
    
    # 分析数据
    if analysis_type == 'lipid':
        analysis = analyze_lipid(df)
        charts = generate_echarts_config(analysis, analysis_type)
        html = generate_html_report({}, analysis, charts, chart_theme)
    elif analysis_type == 'biochem':
        analysis = analyze_biochem(df)
        charts = generate_echarts_config(analysis, analysis_type)
        html = generate_html_report({}, analysis, charts, chart_theme)
    elif analysis_type == 'vitals' or '血压' in str(df.columns) or 'BP' in str(df.columns) or '收缩压' in str(df.columns):
        # 血压数据特殊处理
        analysis = analyze_bp(df)
        html = generate_bp_html(df, analysis, chart_theme)
    else:
        analysis = {'error': '暂不支持该类型分析'}
        html = '<h1>暂不支持该数据类型</h1>'
    
    # 保存报告
    if output_format == 'html':
        output_path = f"./reports/report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        Path('./reports').mkdir(exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"[SUCCESS] 报告已生成: {output_path}")
        
        return {
            'analysis': analysis,
            'output_path': output_path,
            'html': html
        }
    
    return {'analysis': analysis}

# 命令行入口
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python medical_viz_core.py <文件路径> [分析类型]")
        sys.exit(1)
    
    file_path = sys.argv[1]
    analysis_type = sys.argv[2] if len(sys.argv) > 2 else 'auto'
    
    result = analyze_and_visualize(file_path, analysis_type)
    print(json.dumps(result['analysis'], indent=2, ensure_ascii=False))
