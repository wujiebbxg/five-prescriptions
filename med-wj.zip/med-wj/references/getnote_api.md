# GetNote API Documentation

## Overview

GetNote provides a knowledge base search API used by the med-wj skill for nutrition, lifestyle, and functional medicine queries.

## API Endpoint

```
POST https://open-api.biji.com/getnote/openapi/knowledge/search
```

## Authentication

Use Bearer token authentication:

```http
Authorization: Bearer MybZUTEYbSH1sIiUawjixxJHKg9bMVGxcTqeovYMRdq9Y2ry6Yj+LFeRTGJPaQ5V9vrqyQGQTlIORj5issPgMY/fWbCrQN3F4w==
```

## Headers

```http
Content-Type: application/json
Connection: keep-alive
Authorization: Bearer {apiKey}
X-OAuth-Version: 1
```

## Request Format

```json
{
  "question": "Your question here",
  "topic_ids": ["knowledge_base_id"],
  "history": [],
  "deep_seek": true,
  "refs": false
}
```

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| question | string | Yes | User's question |
| topic_ids | array | Yes | Array of knowledge base IDs |
| history | array | No | Conversation history (empty for new queries) |
| deep_seek | boolean | No | Enable deep search for better results |
| refs | boolean | No | Include references in response |

## Response Format

The API returns either JSON or text response.

**JSON Response:**

```json
{
  "c": {
    "answers": "Answer content here"
  }
}
```

**Alternative formats:**

```json
{
  "answer": "Answer content here"
}
```

```json
{
  "content": "Answer content here"
}
```

## Python Usage Example

```python
import requests

url = "https://open-api.biji.com/getnote/openapi/knowledge/search"
headers = {
    "Content-Type": "application/json",
    "Connection": "keep-alive",
    "Authorization": f"Bearer {GETNOTE_API_KEY}",
    "X-OAuth-Version": "1"
}
data = {
    "question": "吃什么补钙？",
    "topic_ids": ["w0E6PpEJ"],
    "history": [],
    "deep_seek": True,
    "refs": False
}

response = requests.post(url, headers=headers, json=data)
result = response.json()
print(result["c"]["answers"])
```

## Knowledge Base IDs

See \`knowledge_bases.md\` for available knowledge base IDs.

## Notes

- Deep seek is enabled for better search results
- References are disabled for cleaner output
- The API supports multiple topic IDs in a single query
