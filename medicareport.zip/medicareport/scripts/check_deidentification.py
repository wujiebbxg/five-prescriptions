#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Medicareport - HIPAA去标识化检查器
检查文档中是否包含18项HIPAA标识符
"""

import re
import sys

# 18项HIPAA标识符检查模式
HIPAA_IDENTIFIERS = {
    "姓名": [
        r'患者姓名[:：]\\s*([\\u4e00-\\u9fa5]{2,4})',
        r'姓名[:：]\\s*([\\u4e00-\\u9fa5]{2,4})',
        r'Name[:：]\\s*(\\w+\\s+\\w+)'
    ],
    "电话号码": [
        r'1[3-9]\\d{9}',
        r'\\d{3,4}-\\d{7,8}',
        r'电话[:：]\\s*(\\d+)'
    ],
    "地址": [
        r'([\\u4e00-\\u9fa5]{2,5}省)?([\\u4e00-\\u9fa5]{2,8}市)?([\\u4e00-\\u9fa5]{2,8}区)?([\\u4e00-\\u9fa5]{2,20}[路街道])',
        r'住址[:：]\\s*([\\u4e00-\\u9fa5]+)',
        r'地址[:：]\\s*([\\u4e00-\\u9fa5]+)'
    ],
    "日期": [
        r'\\d{4}年\\d{1,2}月\\d{1,2}日',
        r'\\d{4}-\\d{2}-\\d{2}',
        r'\\d{4}/\\d{2}/\\d{2}'
    ],
    "身份证号": [
        r'\\d{17}[\\dXx]',
        r'身份证[:：]\\s*(\\d+)'
    ],
    "病历号": [
        r'病历号[:：]\\s*(\\w+)',
        r'住院号[:：]\\s*(\\w+)',
        r'门诊号[:：]\\s*(\\w+)'
    ],
    "邮箱": [
        r'[\\w.-]+@[\\w.-]+\\.\\w+'
    ],
    "社保号": [
        r'社保号[:：]\\s*(\\d+)',
        r'医保号[:：]\\s*(\\d+)'
    ]
}

def check_deidentification(file_path):
    """检查文档去标识化情况"""
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"❌ 无法读取文件：{e}")
        return False
    
    findings = []
    
    for identifier_name, patterns in HIPAA_IDENTIFIERS.items():
        for pattern in patterns:
            matches = re.finditer(pattern, content)
            for match in matches:
                # 获取上下文
                start = max(0, match.start() - 20)
                end = min(len(content), match.end() + 20)
                context = content[start:end].replace('\\n', ' ')
                
                findings.append({
                    "type": identifier_name,
                    "match": match.group(),
                    "context": context,
                    "position": match.start()
                })
    
    print("=" * 60)
    print("HIPAA去标识化检查报告")
    print("=" * 60)
    print()
    
    if not findings:
        print("✅ 未发现明显的HIPAA标识符")
        print("   文档看起来已经过适当去标识化处理")
        return True
    
    # 按类型分组
    by_type = {}
    for finding in findings:
        t = finding["type"]
        if t not in by_type:
            by_type[t] = []
        by_type[t].append(finding)
    
    print(f"⚠️  发现 {len(findings)} 处潜在标识符（涉及 {len(by_type)} 种类型）：")
    print()
    
    for identifier_type, items in by_type.items():
        print(f"📌 {identifier_type} ({len(items)} 处)")
        for item in items[:3]:  # 只显示前3个
            print(f"   匹配：'{item['match']}'")
            print(f"   上下文：...{item['context']}...")
            print()
        if len(items) > 3:
            print(f"   ... 还有 {len(items) - 3} 处 ...")
            print()
    
    print("-" * 60)
    print("建议：")
    print("1. 使用'患者'、'该患者'代替具体姓名")
    print("2. 年龄使用范围描述（如'60多岁'）")
    print("3. 日期使用相对时间（如'3天前'）")
    print("4. 删除或模糊化具体地址信息")
    print("5. 移除所有身份证号、病历号等唯一标识")
    print()
    
    return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：python3 check_deidentification.py <病历文件路径>")
        print()
        print("检查文档是否包含18项HIPAA标识符")
        sys.exit(1)
    
    file_path = sys.argv[1]
    check_deidentification(file_path)
