---
name: link-summarizer
description: "链接内容提取与摘要技能。当用户需要提取网页链接内容、整理文章摘要、生成内容简报时调用。支持单链接提取、批量处理和自定义摘要长度。"
---

# Link Summarizer - 链接内容提取与摘要

## 功能

提供网页链接内容提取和智能摘要功能：
- 🔗 **链接内容提取** - 提取网页正文内容，去除广告和导航
- 📝 **智能摘要** - 自动生成文章摘要，支持自定义长度
- 📚 **批量处理** - 同时处理多个链接，生成简报
- 💾 **多格式输出** - 支持 Markdown、JSON、纯文本格式

## 触发条件

当用户需要以下操作时调用：
- "提取这个链接的内容"
- "帮我摘要这篇文章"
- "整理这些链接的简报"
- "读取网页内容"
- "生成内容摘要"

## 使用方法

### 1. 提取链接内容

```bash
python3 "/root/.openclaw/skills/link-summarizer/scripts/link_summarizer.py" extract <URL>
```

**示例：**
```bash
python3 "/root/.openclaw/skills/link-summarizer/scripts/link_summarizer.py" extract "https://example.com/article"
```

### 2. 提取并摘要

```bash
python3 "/root/.openclaw/skills/link-summarizer/scripts/link_summarizer.py" summarize <URL> [--max-length 500]
```

**示例：**
```bash
python3 "/root/.openclaw/skills/link-summarizer/scripts/link_summarizer.py" summarize "https://example.com/article" --max-length 300
```

### 3. 批量处理

```bash
python3 "/root/.openclaw/skills/link-summarizer/scripts/link_summarizer.py" batch <URL1> <URL2> ...
```

**示例：**
```bash
python3 "/root/.openclaw/skills/link-summarizer/scripts/link_summarizer.py" batch \
  "https://example.com/article1" \
  "https://example.com/article2" \
  "https://example.com/article3"
```

## 功能特点

| 功能 | 说明 |
|------|------|
| 内容提取 | 自动识别正文，去除广告、导航栏等干扰内容 |
| 智能摘要 | 使用 AI 模型生成高质量摘要 |
| 自定义长度 | 支持设置摘要字数限制（默认500字） |
| 批量处理 | 一次处理多个链接，生成汇总简报 |
| 多格式输出 | 支持 Markdown、JSON、纯文本 |

## 使用场景

### 场景1：日常阅读摘要
快速了解长文核心内容，节省时间。

### 场景2：信息收集整理
收集多个来源的信息，生成统一简报。

### 场景3：研究资料整理
整理研究相关的网页资料，提取关键信息。

### 场景4：新闻资讯汇总
汇总每日新闻，生成个人资讯简报。

## 输出格式

### JSON 格式示例
```json
{
  "url": "https://example.com/article",
  "title": "文章标题",
  "summary": "文章摘要内容...",
  "content": "完整正文内容...",
  "word_count": 1500,
  "reading_time": "5分钟"
}
```

### Markdown 格式示例
```markdown
# 文章标题

**来源：** https://example.com/article
**摘要：** 文章摘要内容...

---

## 正文

完整正文内容...
```

## 依赖

- Python 3.8+
- 系统 web_fetch 工具
- AI 模型（用于摘要生成）

## 注意事项

- 部分网站可能有反爬虫机制，提取可能失败
- 摘要质量取决于原文质量和 AI 模型能力
- 建议对重要内容进行人工核对

## 未来优化

- [ ] 支持更多网页格式（PDF、视频字幕等）
- [ ] 添加关键词提取功能
- [ ] 支持定时自动抓取 RSS 源
- [ ] 添加内容分类和标签功能
