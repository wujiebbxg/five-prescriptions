---
name: word-docx
description: Read and generate Word documents with correct structure, styles, and cross-platform compatibility.
author: ivangdavila
---

# Word DOCX Skill

Read and generate Word documents with correct structure, styles, and cross-platform compatibility.

## Features

- ✅ Read Word documents (.docx)
- ✅ Generate Word documents with proper formatting
- ✅ Support for styles, tables, images
- ✅ Cross-platform compatibility

## Use Cases

- Convert content to professional Word documents
- Read and extract content from Word files
- Generate reports with proper formatting
- Template-based document generation

## Dependencies

Typically uses Python libraries:
- `python-docx` - For reading/writing Word documents

Install:
```bash
pip install python-docx
```

## Usage

### Read Word Document

```python
from docx import Document

doc = Document('input.docx')
for para in doc.paragraphs:
    print(para.text)
```

### Generate Word Document

```python
from docx import Document

doc = Document()
doc.add_heading('Title', 0)
doc.add_paragraph('Content here')
doc.save('output.docx')
```

## Notes

- This skill provides guidance on working with Word documents
- For Markdown to DOCX conversion, see also `markdown-converter` skill
