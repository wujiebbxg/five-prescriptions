# Knowledge Base Configuration

## Overview

This document contains the knowledge base IDs used by the GetNote API for different query categories in the med-wj skill.

## Knowledge Bases

| Category | Type Key | Knowledge Base ID | Description |
|----------|----------|-------------------|-------------|
| Nutrition | \`nutrition\` | \`w0E6PpEJ\` | Nutrition and diet-related queries |
| Lifestyle | \`lifestyle\` | \`ww0E73xyn\` | Lifestyle and wellness queries |
| Functional Medicine | \`functional_medicine\` | \`zJKPQaWn\` | Nutrients and functional medicine queries |

## Category Mapping

The skill automatically maps user queries to the appropriate knowledge base based on the detected category:

1. **Medical queries** → Use Baichuan-M3 AI model (not a knowledge base)
2. **Nutrition queries** → Knowledge base ID: \`w0E6PpEJ\`
3. **Lifestyle queries** → Knowledge base ID: \`ww0E73xyn\`
4. **Functional Medicine queries** → Knowledge base ID: \`zJKPQaWn\`

## Usage Example

```python
GETNOTE_IDS = {
    "nutrition": "w0E6PpEJ",
    "lifestyle": "ww0E73xyn",
    "functional_medicine": "zJKPQaWn"
}

# Get knowledge base ID for nutrition
topic_id = GETNOTE_IDS["nutrition"]  # Returns: "w0E6PpEJ"
```

## Adding New Knowledge Bases

To add a new knowledge base category:

1. Create the knowledge base in GetNote platform
2. Note the new knowledge base ID
3. Add the mapping to the \`GETNOTE_IDS\` dictionary in \`med_wj.py\`
4. Update this documentation
