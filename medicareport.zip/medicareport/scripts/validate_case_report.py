#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Medicareport - 病例报告CARE指南合规性验证器
"""

import re
import sys

def validate_case_report(file_path):
    """验证病例报告是否符合CARE指南"""
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"❌ 无法读取文件：{e}")
        return False
    
    checks = {
        "标题包含'病例报告'": bool(re.search(r'病例报告|case report', content, re.IGNORECASE)),
        "有摘要部分": bool(re.search(r'## 摘要|## Abstract', content)),
        "有引言部分": bool(re.search(r'## 引言|## Introduction', content)),
        "有病例信息": bool(re.search(r'## 病例信息|## 患者信息|## Patient', content)),
        "有临床发现": bool(re.search(r'## 临床发现|## Clinical', content)),
        "有时间线": bool(re.search(r'## 时间线|## Timeline', content)),
        "有诊断评估": bool(re.search(r'## 诊断评估|## Diagnostic', content)),
        "有治疗干预": bool(re.search(r'## 治疗干预|## 治疗|## Therapeutic', content)),
        "有随访结果": bool(re.search(r'## 随访|## Follow-up|## 结果|## Outcomes', content)),
        "有讨论部分": bool(re.search(r'## 讨论|## Discussion', content)),
        "有知情同意声明": bool(re.search(r'知情同意|informed consent', content, re.IGNORECASE)),
        "有参考文献": bool(re.search(r'## 参考文献|## References', content)),
    }
    
    # 字数统计
    word_count = len(content.replace(' ', '').replace('\\n', ''))
    
    print("=" * 50)
    print("病例报告CARE指南合规性检查")
    print("=" * 50)
    print()
    
    passed = 0
    failed = 0
    
    for check_name, result in checks.items():
        status = "✅ 通过" if result else "❌ 未通过"
        print(f"{status} - {check_name}")
        if result:
            passed += 1
        else:
            failed += 1
    
    print()
    print("-" * 50)
    print(f"文档字数：{word_count} 字符")
    print(f"通过检查：{passed}/{len(checks)}")
    print(f"未通过：{failed}")
    print()
    
    if failed == 0:
        print("✅ 恭喜！您的病例报告符合CARE指南基本要求")
    else:
        print(f"⚠️  还有 {failed} 项需要完善")
    
    return failed == 0

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：python3 validate_case_report.py <病历文件路径>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    validate_case_report(file_path)
